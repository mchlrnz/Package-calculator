﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Package_calculator
{
    public class Program
    {
        static void Main(string[] args)
        {
            InitializeDeliveryCompute();
        }

        static void InitializeDeliveryCompute()
        {
            try
            {
                int weight = 110, height = 20, width = 55, length = 120;

                Console.Write("Weight: ");
                weight = Convert.ToInt32(Console.ReadLine());
                Console.Write("Height: ");
                height = Convert.ToInt32(Console.ReadLine());
                Console.Write("Width: ");
                width = Convert.ToInt32(Console.ReadLine());
                Console.Write("Length: ");
                length = Convert.ToInt32(Console.ReadLine());

                if (weight < 0 || height < 0 || width < 0 || length < 0)
                {
                    Console.WriteLine("Inputs must not be negative");
                    Console.ReadKey();
                    Console.Clear();
                    InitializeDeliveryCompute();
                }


                string category = "";
                double cost = 0;

                ComputeDelivery(weight, height, width, length, out category, out cost);

                Console.WriteLine("Category: " + category);
                Console.WriteLine(cost != 0 ? "Cost: $" + cost : "Cost: N/A");
                Console.WriteLine("Press any key to calculate another delivery");
                Console.ReadKey();
                Console.Clear();
                InitializeDeliveryCompute();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message.ToString());
                Console.WriteLine("Press any key to calculate another delivery");
                Console.ReadKey();
                Console.Clear();
                InitializeDeliveryCompute();
            }
        }

        public static void ComputeDelivery(int weight, int height, int width, int length, out string category, out double cost)
        {
            double volume = length * width * height;

            if (weight > 25)
            {
                category = "Rejected";
                cost = 0;
            }
            else if (weight > 10)
            {
                category = "Heavy Package";
                cost = 15 * weight;
            }
            else if (volume < 1500)
            {
                category = "Small Package";
                cost = 0.05 * volume;
            }
            else if (volume < 2500)
            {
                category = "Medium Package";
                cost = 0.04 * volume;
            }
            else
            {
                category = "Large Package";
                cost = 0.03 * volume;
            }
        }
    }
}
