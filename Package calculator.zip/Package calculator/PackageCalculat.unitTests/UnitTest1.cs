﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Package_calculator;

namespace PackageCalculat.unitTests
{
    [TestClass]
    public class CalculateDeliveryTests
    {
        [TestMethod]
        public void CalculateDelivery_ReturnsRejected()
        {
            // Arrange
            int weight = 110, height = 20, width = 55, length = 120;
            string category = "";
            double cost = 0;

            // Act
            Program.ComputeDelivery(weight, height, width, length, out category, out cost);


            // Assert
            Assert.AreEqual("Rejected", category);
            Assert.AreEqual(0, cost);
        }

        [TestMethod]
        public void CalculateDelivery_ReturnsHeavyPackage()
        {
            // Arrange
            int weight = 22, height = 5, width = 5, length = 5;
            string category = "";
            double cost = 0;

            // Act
            Program.ComputeDelivery(weight, height, width, length, out category, out cost);


            // Assert
            Assert.AreEqual("Heavy Package", category);
            Assert.AreEqual(330, cost);
        }

        [TestMethod]
        public void CalculateDelivery_ReturnsSmallPackage()
        {
            // Arrange
            int weight = 2, height = 3, width = 10, length = 12;
            string category = "";
            double cost = 0;

            // Act
            Program.ComputeDelivery(weight, height, width, length, out category, out cost);


            // Assert
            Assert.AreEqual("Small Package", category);
            Assert.AreEqual(18, cost);
        }

        [TestMethod]
        public void CalculateDelivery_ReturnsMediumPackage()
        {
            // Arrange
            int weight = 10, height = 10, width = 10, length = 20;
            string category = "";
            double cost = 0;

            // Act
            Program.ComputeDelivery(weight, height, width, length, out category, out cost);


            // Assert
            Assert.AreEqual("Medium Package", category);
            Assert.AreEqual(80, cost);
        }

        [TestMethod]
        public void CalculateDelivery_ReturnsLargePackage()
        {
            // Arrange
            int weight = 10, height = 20, width = 20, length = 20;
            string category = "";
            double cost = 0;

            // Act
            Program.ComputeDelivery(weight, height, width, length, out category, out cost);


            // Assert
            Assert.AreEqual("Large Package", category);
            Assert.AreEqual(240, cost);
        }
    }
}
